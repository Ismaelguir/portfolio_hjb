import streamlit as st

def render():
    st.header("HJB")
    st.info("À faire : heatmap/coupes de pi*(t,x) et/ou V(t,x) + métadonnées.")
