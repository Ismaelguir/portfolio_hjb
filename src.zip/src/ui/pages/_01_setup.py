import streamlit as st

def render():
    st.header("Setup")
    st.info("À faire : sélection actif, x0, r, gamma, init/reset.")
